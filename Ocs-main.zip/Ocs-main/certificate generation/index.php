<?php
include "../connection/connection.php";

if (isset($_POST['prn'])) {
    // Retrieve the PRN value from the POST data
    $prnParam = $_POST['prn'];

    // Fetch student data from the database
    $sql = "SELECT * FROM student WHERE PRN = $prnParam";
    $result = $connection->query($sql);

    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        $name = $row['Firstname'] . " " . $row['Middlename'] . " " .  $row['Lastname'];
        $prn = $row['PRN'];
        $Year_of_Study = $row['Year_of_study'];
        $Branch = $row['Branch'];
        $Section = $row['Section'];

        // Create image
        $font = "Raleway-Regular.ttf";
        $image = imagecreatefromjpeg("format.jpg");
        $color = imagecolorallocate($image, 0, 0, 0);

        // Calculate the width and height of the name text
        $bbox_name = imagettfbbox(40, 0, $font, $name);
        $name_width = $bbox_name[2] - $bbox_name[0];
        $name_height = $bbox_name[1] - $bbox_name[7];

        // Calculate the width and height of the PRN text
        $bbox_prn = imagettfbbox(40, 0, $font, $prn);
        $prn_width = $bbox_prn[2] - $bbox_prn[0];
        $prn_height = $bbox_prn[1] - $bbox_prn[7];

        // Calculate the width and height of the Year of Study text
        $bbox_year = imagettfbbox(40, 0, $font, $Year_of_Study);
        $year_width = $bbox_year[2] - $bbox_year[0];
        $year_height = $bbox_year[1] - $bbox_year[7];

        // Calculate the width and height of the Branch text
        $bbox_branch = imagettfbbox(40, 0, $font, $Branch);
        $branch_width = $bbox_branch[2] - $bbox_branch[0];
        $branch_height = $bbox_branch[1] - $bbox_branch[7];

        // Calculate the width and height of the Section text
        $bbox_section = imagettfbbox(40, 0, $font, $Section);
        $section_width = $bbox_section[2] - $bbox_section[0];
        $section_height = $bbox_section[1] - $bbox_section[7];

        // Position the name text on the image
        $name_x = ($image_width - $name_width) / 2; // Centered horizontally
        $name_y = 200; // Example y-coordinate
        imagettftext($image, 40, 0, $name_x, $name_y, $color, $font, $name);

        // Position the PRN text on the image
        $prn_x = ($image_width - $prn_width) / 2; // Centered horizontally
        $prn_y = $name_y + $name_height + 20; // Example y-coordinate, 20 pixels below the name
        imagettftext($image, 40, 0, $prn_x, $prn_y, $color, $font, $prn);

        // Position the Year of Study text on the image
        $year_x = ($image_width - $year_width) / 2; // Centered horizontally
        $year_y = $prn_y + $prn_height + 20; // Example y-coordinate, 20 pixels below the PRN
        imagettftext($image, 40, 0, $year_x, $year_y, $color, $font, $Year_of_Study);

        // Position the Branch text on the image
        $branch_x = ($image_width - $branch_width) / 2; // Centered horizontally
        $branch_y = $year_y + $year_height + 20; // Example y-coordinate, 20 pixels below the Year of Study
        imagettftext($image, 40, 0, $branch_x, $branch_y, $color, $font, $Branch);

        // Position the Section text on the image
        $section_x = ($image_width - $section_width) / 2; // Centered horizontally
        $section_y = $branch_y + $branch_height + 20; // Example y-coordinate, 20 pixels below the Branch
        imagettftext($image, 40, 0, $section_x, $section_y, $color, $font, $Section);

        // Send image to browser
        header('Content-Type: image/jpeg');
        // Output image directly to browser
        imagejpeg($image);
        imagedestroy($image);
    }
    // Include any necessary cleanup or additional actions here
    include "../connection/break.php";
} else {
    echo "No PRN parameter provided.";
}
